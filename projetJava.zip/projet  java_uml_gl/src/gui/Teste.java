package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JProgressBar;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JToggleButton;
import javax.swing.JSlider;

public class Teste extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teste frame = new Teste();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teste() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList list = new JList();
		list.setBackground(Color.BLACK);
		list.setBounds(128, 130, 49, -32);
		contentPane.add(list);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setValue(15);
		progressBar.setBounds(45, 28, 146, 14);
		contentPane.add(progressBar);
		
		JList list_1 = new JList();
		list_1.setBounds(111, 58, 177, 169);
		contentPane.add(list_1);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerListModel(new String[] {"1AP", "2Ap", "2ite-1", "2ite-2", "isic-1", "isic-2", "GI-1", "GI-2", "GEE-1", "GEE-2"}));
		spinner.setBounds(298, 28, 108, 20);
		contentPane.add(spinner);
		
		JToggleButton tglbtnGggg = new JToggleButton("gggg");
		tglbtnGggg.setBounds(311, 94, 123, 23);
		contentPane.add(tglbtnGggg);
		
		JSlider slider = new JSlider();
		slider.setBounds(47, 184, 200, 26);
		contentPane.add(slider);
	}
}

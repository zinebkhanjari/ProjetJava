package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class EventsManager extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EventsManager frame = new EventsManager();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EventsManager() {
		setTitle("gestion des evenements ");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 610, 556);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
		label.setBounds(235, 27, 132, 150);
		contentPane.add(label);
		
		JButton btnAjouterUnEvenement = new JButton("ajouter un evenement");
		btnAjouterUnEvenement.setBounds(60, 231, 162, 23);
		contentPane.add(btnAjouterUnEvenement);
		
		JButton btnModifierUnEvenemnt = new JButton("modifier un evenemnt ");
		btnModifierUnEvenemnt.setBounds(60, 284, 162, 23);
		contentPane.add(btnModifierUnEvenemnt);
		
		JButton btnSuprimmerUnEvenement = new JButton("suprimmer un evenement ");
		btnSuprimmerUnEvenement.setBounds(60, 339, 162, 23);
		contentPane.add(btnSuprimmerUnEvenement);
	}
}
